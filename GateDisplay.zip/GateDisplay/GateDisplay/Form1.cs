﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GateDisplay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timSPRead.Start();
            refreshLabels("1", "OPEN", "2");
        }

        /// <summary>
        /// Refreshes the text in the labels on the display
        /// </summary>
        void refreshLabels(String gateID, String gateState, String otherGate)
        {
            lblID.Text = "GATE " + gateID;
            lblState.Text = gateState;
            lblOtherGate.Text = "Go to gate " + otherGate;

            if(gateState == "CLOSED")
            {
                BackColor = Color.Red;
                lblOtherGate.Visible = true;
            }
            else
            {
                BackColor = Color.YellowGreen;
                lblOtherGate.Visible = false;
            }
        }

        private void timSPRead_Tick(object sender, EventArgs e)
        {
            if(spGate.IsOpen)
            {
                if(spGate.BytesToRead > 0)
                {
                    // read the message sent from the gate into a string
                    String message = "";
                    spGate.ReadTo(message);

                    // parse the message
                    if (message.StartsWith("G"))
                    {
                        // the values extracted from the message
                        String gateID = "0";
                        String gateState = "CLOSED";
                        String otherGateID = "";

                        // message format is like this:
                        // G#<id>#<state>#<other gate id>
                        // so data[1] == id, data[2] = state and data[3] = other gate id
                        String[] data = message.Split('#');
                        gateID = data[1];
                        if(data[2] == "O")
                        {
                            gateState = "OPEN";
                        }
                        else
                        {
                            gateState = "CLOSED";
                        }
                        otherGateID = data[3];

                        // refresh the display
                        refreshLabels(gateID, gateState, otherGateID);
                    }
                }
            }
            else
            {
                spGate.Open();
            }
        }

        private void lblID_Click(object sender, EventArgs e)
        {

        }

        private void lblID_Click_1(object sender, EventArgs e)
        {

        }
    }
}
